import 'package:flutter/material.dart';

class ColorsRes {
  static Color themeBlue = Color(0xff0C0C4D);
  static Color colorWhite = Color.fromARGB(255, 255, 255, 255);
  static Color textGrey = Color(0xff828282);
  static Color themeTextBlue = Color(0xff0C0C4D);
  static Color textBlack = Color(0xFF1D1D1D);
  static Color lightBlue = Color(0xFFC5E2F4);
  static Color blue = Color(0xFF0D99FF);
  static Color canvasColor = Colors.white;
}
