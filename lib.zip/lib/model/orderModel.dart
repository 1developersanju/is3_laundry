class Order {
  final String id;
  final String serviceType;
  final String location;
  final String status;
  final int price;
  final DateTime date;

  Order({
    required this.id,
    required this.serviceType,
    required this.location,
    required this.status,
    required this.price,
    required this.date,
  });

  // From Firebase
  // factory Order.fromMap(Map<String, dynamic> data, String id) {
  //   return Order(
  //     id: id,
  //     serviceType: data['serviceType'] ?? '',
  //     location: data['location'] ?? '',
  //     status: data['status'] ?? '',
  //     price: data['price'] ?? 0,
  //     date: (data['date'] as Timestamp).toDate(),
  //   );
  // }

  // // To Firebase
  // Map<String, dynamic> toMap() {
  //   return {
  //     'serviceType': serviceType,
  //     'location': location,
  //     'status': status,
  //     'price': price,
  //     'date': date,
  //   };
  // }
}


final List<Order> orders = [
  Order(
    id: '1',
    serviceType: 'Dry wash',
    location: 'LIG colony, cbe',
    status: 'Completed',
    price: 500,
    date: DateTime.now(),
  ),
  Order(
    id: '2',
    serviceType: 'Dry wash',
    location: 'LIG colony, cbe',
    status: '',
    price: 500,
    date: DateTime.now().subtract(Duration(days: 1)),
  ),
  Order(
    id: '3',
    serviceType: 'Dry wash',
    location: 'LIG colony, cbe',
    status: '',
    price: 500,
    date: DateTime.now().subtract(Duration(days: 7)),
  ),
];
